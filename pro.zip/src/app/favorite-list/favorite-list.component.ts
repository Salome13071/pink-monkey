import { Component } from '@angular/core';

@Component({
  selector: 'app-favorite-list',
  standalone: true,
  imports: [],
  templateUrl: './favorite-list.component.html',
  styleUrl: './favorite-list.component.css'
})
export class FavoriteListComponent {

}
